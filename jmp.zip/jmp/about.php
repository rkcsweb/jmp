<?php
include_once('layouts/header.php');
?>

<section>
    <div class="container-flude">
        <div class="bg-info text-center">
            <h1>ABOUT US</h1>
            <p>
                Incorporated on the 29th of September 1960, as a limited liability company and pioneer wheat miller in Nigeria, Flour Mills of Nigeria Plc (FMN) started out on a journey that has seen the company evolve into what is now one of the biggest brands in the foods and agro-allied industry in Africa. Over the years, the FMN brand grew tremendously from operating as a single business, flour miller, to a vast business group with strategic investments that cover key sectors of the Nigerian economy. The group’s operations can be categorized into four major sectors of Food, Sugar, Agro-allied, and Support services. Our foray into the Agric sector started in 1978, with the acquisition of a 10,000-hectare farm in Kaboji, Niger state as part of an investment and expansion strategy designed to create value in the supply chain and reduce the reliance on imported raw materials. Since then, we have made substantial investments in the primary processing of locally grown soybean, palm fruit, cassava, maize, sugar cane, sorghum, and the storage, aggregation and distribution of locally sourced grains. At FMN, we are passionate about, ‘feeding the nation.’ for over five decades, we have maintained a rich tradition of enhancing the quality of living for Nigerian families by producing a wholesome portfolio of food options – The company’s iconic food brand, ‘Golden Penny,’ is a household name that is trusted by many for good food and for daily nourishment.
            </p>
        </div>
        <div>
            <h1>Brief introduction</h1>
            <p>
                
                Raymond mill is widely used in the field of metallurgy, building materials, stone industry and mining to process powder. This mill is used to grind non-flammable and non-explosive material which has Moh's hardness below 9 and humidity less than 6%, such as gypsum, talc, calcite, limestone, marble, feldspar, barite, dolomite, granite, kaolin, bentonite, bauxite, iron ore, etc. the final product with size from 30 to 425 mesh can meet different customers' various requests.

            </p>
        </div>

    </div>
    <div class="container-flude">
        <div>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt earum impedit modi magnam, deleniti eveniet fuga assumenda beatae numquam consectetur at quisquam maiores a adipisci atque consequatur? Natus, rerum quia?</div>
        <div class="bg-info">sdafdlkjl</div>
    </div>
</section>
<section id="counter-section" class="container-fluid counter-calltoaction bg-fixed overlay" data-100-bottom="background-position: 50% 100px;" data-top-bottom="background-position: 50% -100px;" style="background-image: url('layouts/img/footer.jpg');">
    <div id="counter" class="container">
        <div class="row col-lg-10 offset-lg-1">
            <!-- Counter -->
            <div class="col-xl-4 col-md-4 card bg-info">
                <div class="counter card">
                    <div class="counter-wrapper bg-secondary card-body text-white">
                        <i class="counter-icon flaticon-children"></i>
                        <!-- insert your final value on data-count= -->
                        <div class="counter-value " data-count="104"></div>
                        <h4 class="card-title">FINSHING</h4>
                            <p class="card-body">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Culpa inventore beatae ab corporis reprehenderit officiis et doloremque. Ducimus asperiores error natus quisquam, dolor, ad sint illum commodi, animi dicta laudantium?</p>
                    </div>
                </div>
                <!-- /counter -->
            </div>
            <!-- /col-lg -->
            <!-- Counter -->
            <div class="col-xl-4 col-md-4 card bg-secondary">
                <div class="counter card">
                    <div class="counter-wrapper bg-info card-body">
                        <i class="counter-icon flaticon-children"></i>
                        <!-- insert your final value on data-count= -->
                        <div class="counter-value " data-count="104"></div>
                        <h4 class="card-title">MACHINE</h4>
                        <p class="card-body">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Culpa inventore beatae ab corporis reprehenderit officiis et doloremque. Ducimus asperiores error natus quisquam, dolor, ad sint illum commodi, animi dicta laudantium?</p>
                    </div>
                </div>
                <!-- /counter -->
            </div>
            <!-- /col-lg -->
            <!-- Counter -->
            <div class="col-xl-4 col-md-4 card bg-secondary">
                <div class="counter card">
                    <div class="counter-wrapper bg-info card-body">
                        <i class="counter-icon flaticon-children"></i>
                        <!-- insert your final value on data-count= -->
                        <div class="counter-value " data-count="104"></div>
                        <h4 class="card-title">PRODUCT QUALITY</h4>
                        <p class="card-body">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Culpa inventore beatae ab corporis reprehenderit officiis et doloremque. Ducimus asperiores error natus quisquam, dolor, ad sint illum commodi, animi dicta laudantium?</p>
                    </div>
                </div>
                <!-- /counter -->
            </div>
            <!-- /col-lg -->
        </div>
        <!-- /row -->
    </div>
    <!-- /container -->
</section>
<section>
    <div class="container-flude">
        <div class="bg-info">sdafdlkjl</div>
        <div>sdafdlkjl</div>
    </div>
    <div class="container-flude">
        <div>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt earum impedit modi magnam, deleniti eveniet fuga assumenda beatae numquam consectetur at quisquam maiores a adipisci atque consequatur? Natus, rerum quia?</div>
        <div class="bg-info">sdafdlkjl</div>
    </div>
</section>
<?php
include_once('layouts/footer.php');
?>
<?php
include_once('layouts/header.php');
?>

<section>
    <div class="container-flude">
        <div class="bg-info">sdafdlkjl</div>
        <div>sdafdlkjl</div>
    </div>
    <div class="container-flude">
        <div>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt earum impedit modi magnam, deleniti eveniet fuga assumenda beatae numquam consectetur at quisquam maiores a adipisci atque consequatur? Natus, rerum quia?</div>
        <div class="bg-info">sdafdlkjl</div>
    </div>
</section>
<section id="counter-section" class="container-fluid counter-calltoaction bg-fixed overlay" data-100-bottom="background-position: 50% 100px;" data-top-bottom="background-position: 50% -100px;" style="background-image: url('layouts/img/footer.jpg');">
    <div id="counter" class="container">
        <div class="row col-lg-10 offset-lg-1">
            <!-- Counter -->
            <div class="col-xl-4 col-md-4 card bg-info">
                <div class="counter card">
                    <div class="counter-wrapper bg-secondary card-body text-white">
                        <i class="counter-icon flaticon-children"></i>
                        <!-- insert your final value on data-count= -->
                        <div class="counter-value " data-count="104"></div>
                        <h4 class="card-title">John Doe</h4>
                        <p class="card-body">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Culpa inventore beatae ab corporis reprehenderit officiis et doloremque. Ducimus asperiores error natus quisquam, dolor, ad sint illum commodi, animi dicta laudantium?</p>
                    </div>
                </div>
                <!-- /counter -->
            </div>
            <!-- /col-lg -->
            <!-- Counter -->
            <div class="col-xl-4 col-md-4 card bg-secondary">
                <div class="counter card">
                    <div class="counter-wrapper bg-info card-body">
                        <i class="counter-icon flaticon-children"></i>
                        <!-- insert your final value on data-count= -->
                        <div class="counter-value " data-count="104"></div>
                        <h4 class="card-title">John Doe</h4>
                        <p class="card-body">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Culpa inventore beatae ab corporis reprehenderit officiis et doloremque. Ducimus asperiores error natus quisquam, dolor, ad sint illum commodi, animi dicta laudantium?</p>
                    </div>
                </div>
                <!-- /counter -->
            </div>
            <!-- /col-lg -->
            <!-- Counter -->
            <div class="col-xl-4 col-md-4 card bg-secondary">
                <div class="counter card">
                    <div class="counter-wrapper bg-info card-body">
                        <i class="counter-icon flaticon-children"></i>
                        <!-- insert your final value on data-count= -->
                        <div class="counter-value " data-count="104"></div>
                        <h4 class="card-title">John Doe</h4>
                        <p class="card-body">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Culpa inventore beatae ab corporis reprehenderit officiis et doloremque. Ducimus asperiores error natus quisquam, dolor, ad sint illum commodi, animi dicta laudantium?</p>
                    </div>
                </div>
                <!-- /counter -->
            </div>
            <!-- /col-lg -->
        </div>
        <!-- /row -->
    </div>
    <!-- /container -->
</section>
<section>
    <div class="container-flude">
        <div class="bg-info">sdafdlkjl</div>
        <div>sdafdlkjl</div>
    </div>
    <div class="container-flude">
        <div>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt earum impedit modi magnam, deleniti eveniet fuga assumenda beatae numquam consectetur at quisquam maiores a adipisci atque consequatur? Natus, rerum quia?</div>
        <div class="bg-info">sdafdlkjl</div>
    </div>
</section>
<?php
include_once('layouts/footer.php');
?>
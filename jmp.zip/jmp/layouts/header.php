<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="layouts/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="layouts/bootstrap/css/bootstrap.icons.css">
    <script src="layouts/bootstrap/js/jquery.slim.min.js"></script>
    <script src="layouts/bootstrap/js/popper.min.js"></script>
    <script src="layouts/bootstrap/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="layouts/css/style.css">
    <title>Home Page</title>
    <link rel="icon" type="image/x-icon" href="layouts/img/favicon-96x96.png">
    <style>
        .dropdown:hover .dropdown-menu {
            display: block;
        }

        .dropdown-menu {
            margin-top: 0;
        }

        /* Make the image fully responsive */
        .carousel-inner img {
            width: 100%;
            height: 100%;
        }
    </style>
    <script>
        $(document).ready(function() {
            $(".dropdown").hover(function() {
                var dropdownMenu = $(this).children(".dropdown-menu");
                if (dropdownMenu.is(":visible")) {
                    dropdownMenu.parent().toggleClass("open");
                }
            });
        });
    </script>
</head>

<body>
    <div class="row l1">
        <div class=" col-md-2 logo">
            <img src="layouts/img/LOGO.png" class="rounded-circle " alt="Cinque Terre" width="50%" height="95%" style="margin-left:30px">
        </div>
        <div class="col-md-10">
            <header class="container text-white iso">
                <h1 >JMP Industry Private Limited</h1>
                <h6>An ISO No. 2200:2018 Company</h6>
                <h6>CIN : US1109UP1994PTC016597</h6>
            </header>
        </div>
    </div>

    <!-- Navbar Starts -->
    <nav class="navbar navbar-expand-sm bg-info text-white ">
        <div>
            <h5>JMP INDUSTRY</h5>
        </div>
        <div class="container ">

            <ul class="nav  ml-auto">
                <li class="nav-item">
                    <a class="nav-link text-white" href="#">HOME</a>
                </li>
                <li class="nav-item">
                    <div class="nav-item dropdown bg-info text-white">
                        <a href="about.php" class="nav-link dropdown-toggle text-white" data-toggle="dropdown">ABOUT US</a>
                        <div class="dropdown-menu bg-info text-white">
                            <a class="dropdown-item" href="about.php">About us</a>
                            <a class="dropdown-item" href="#">Link 2</a>
                            <a class="dropdown-item" href="#">Link 3</a>
                        </div>
                    </div>

                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="job.php">JOB</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="infrastructure.php">INFRASTUCTURE</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="service.php">SERVICE</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="contact.php">CONTACT US</a>
                </li>
            </ul>
        </div>
    </nav>
    <!-- /navbar -->
    <!--carasoul-->
    <div id="demo" class="carousel slide" data-ride="carousel">

        <!-- Indicators -->
        <ul class="carousel-indicators">
            <li data-target="#demo" data-slide-to="0" class="active"></li>
            <li data-target="#demo" data-slide-to="1"></li>
            <li data-target="#demo" data-slide-to="2"></li>
            <li data-target="#demo" data-slide-to="3"></li>
            <li data-target="#demo" data-slide-to="4"></li>
            <li data-target="#demo" data-slide-to="6"></li>
        </ul>

        <!-- The slideshow -->
        <div class="carousel-inner container-fluid" width="50%" height="10%">
            <div class="carousel-item active">
                <img src="layouts/img/slider/i1.jpg" alt="Los Angeles" width="50%" height="40%">
            </div>
            <div class="carousel-item">
                <img src="layouts/img/slider/i2.jpg" alt="Chicago" width="50%" height="40%">
            </div>
            <div class="carousel-item">
                <img src="layouts/img/slider/i3.jpg" alt="New York" width="50%" height="40%">
            </div>
            <div class="carousel-item ">
                <img src="layouts/img/slider/i4.jpg" alt="Los Angeles" width="50%" height="40%">
            </div>
            <div class="carousel-item">
                <img src="layouts/img/slider/i5.jpg" alt="Chicago" width="50%" height="40%">
            </div>
            <div class="carousel-item">
                <img src="layouts/img/slider/i6.jpg" alt="New York" width="50%" height="40%">
            </div>
        </div>

        <!-- Left and right controls -->
        <a class="carousel-control-prev" href="#demo" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </a>
        <a class="carousel-control-next" href="#demo" data-slide="next">
            <span class="carousel-control-next-icon"></span>
        </a>

    </div>
    <!-- /end carasoul-->
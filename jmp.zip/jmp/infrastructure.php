<?php
include_once('layouts/header.php');

$dir_path = "layouts/img/infra/";
$exten_array = array('jpg', 'png', 'jpeg');
if (is_dir($dir_path)) {
    $file_img = scandir($dir_path);
}

?>

<section>
    <div class="container-flude">
        <div class="bg-info text-center p-3 m-1">
            <h1>INFRASTRUCTURE</h1>
            <p>
                Incorporated on the 29th of September 1960, as a limited liability company and pioneer wheat miller in Nigeria, Flour Mills of Nigeria Plc (FMN) started out on a journey that has seen the company evolve into what is now one of the biggest brands in the foods and agro-allied industry in Africa. Over the years, the FMN brand grew tremendously from operating as a single business, flour miller, to a vast business group with strategic investments that cover key sectors of the Nigerian economy. The group’s operations can be categorized into four major sectors of Food, Sugar, Agro-allied, and Support services. Our foray into the Agric sector started in 1978, with the acquisition of a 10,000-hectare farm in Kaboji, Niger state as part of an investment and expansion strategy designed to create value in the supply chain and reduce the reliance on imported raw materials. Since then, we have made substantial investments in the primary processing of locally grown soybean, palm fruit, cassava, maize, sugar cane, sorghum, and the storage, aggregation and distribution of locally sourced grains. At FMN, we are passionate about, ‘feeding the nation.’ for over five decades, we have maintained a rich tradition of enhancing the quality of living for Nigerian families by producing a wholesome portfolio of food options – The company’s iconic food brand, ‘Golden Penny,’ is a household name that is trusted by many for good food and for daily nourishment.
            </p>
        </div>
        <div class="container-fluid  ">
            gj
            <?php

            for ($i = 0; $i<count(($file_img)); $i++) {
                if ($file_img[$i] != '.' && $file_img[$i] != '..') {
            ?>
                <td> <img src="layouts/img/infra/<?php echo $file_img[$i];?>" alt="<?php echo $file_img[$i]?>;"
                         width="100%" height="100%" class="imgs"></td>
               

                    
                    


            <?php
                }
            }


            ?>

        </div>

    </div>

</section>

<?php
//include_once('layouts/footer.php');
?>